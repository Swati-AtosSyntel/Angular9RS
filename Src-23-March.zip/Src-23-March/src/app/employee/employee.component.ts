import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  firstName:string;
  lastName:string;
  fullName="";
  colors=['Red','Green','Blue','Orange']
  show=true;
  month=1;
  constructor() { 
    this.firstName="Swati";
    this.lastName="Bhirud";
  }

  ngOnInit(): void {
  }
getFullName():any{
  this.fullName=this.firstName+" "+this.lastName;
}
}
