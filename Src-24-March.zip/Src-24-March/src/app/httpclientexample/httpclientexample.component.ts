import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Repository } from './repository';
@Component({
  selector: 'app-httpclientexample',
  templateUrl: './httpclientexample.component.html',
  styleUrls: ['./httpclientexample.component.css']
})
export class HttpclientexampleComponent implements OnInit {
  username="swati";
  baseURL="https://api.github.com";
repos:Repository[];

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.getRepository();
  }
getRepository(){
  return this.http.get<Repository[]>(
    this.baseURL+'/users/'+this.username+'/repos'

  ).subscribe(
    (response)=>{
      console.log("resposne received");
      console.log(response);
      this.repos=response;
    },
    (error)=>{
      console.log("Request Failed");
    },
    ()=>{
      console.log("Request Completed");
    }
  )
}
}
